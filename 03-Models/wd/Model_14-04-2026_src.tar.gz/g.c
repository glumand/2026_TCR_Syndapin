#include <R.h>
 #include <math.h>
 void g_23z68uzz ( double * x, double * y, double * p, int * n, int * k, int * l ) {
 for(int i = 0; i< *n; i++) {
 y[0+i**l] = log2(x[0+i**k]+x[4+i**k]+x[6+i**k]+x[1+i**k]+x[2+i**k]+x[3+i**k]+x[5+i**k]+p[0])+p[1] ;
y[1+i**l] = log2(x[5+i**k]+p[2])+p[3] ;
y[2+i**l] = log2(x[5+i**k]+x[3+i**k]+p[4])+p[5] ; 
}
}