#include <R.h>
 #include <math.h>
 void p_1_shCTRL_deriv_6yui989k ( double * x, double * y, double * p, int * n, int * k, int * l ) {
 for(int i = 0; i< *n; i++) {
 y[0+i**l] = exp(p[0]*log(10.0))*log(10.0) ;
y[25+i**l] = exp(p[1]*log(10.0))*log(10.0) ;
y[50+i**l] = exp(p[2]*log(10.0))*log(10.0) ;
y[76+i**l] = exp(p[3]*log(10.0))*log(10.0) ;
y[101+i**l] = exp(p[4]*log(10.0))*log(10.0) ;
y[126+i**l] = exp(p[5]*log(10.0))*log(10.0) ;
y[151+i**l] = exp(p[6]*log(10.0))*log(10.0) ;
y[176+i**l] = exp(p[7]*log(10.0))*log(10.0) ;
y[201+i**l] = exp(p[8]*log(10.0))*log(10.0) ;
y[226+i**l] = exp(p[9]*log(10.0))*log(10.0) ;
y[251+i**l] = exp(p[10]*log(10.0))*log(10.0) ;
y[276+i**l] = exp(p[11]*log(10.0))*log(10.0) ;
y[301+i**l] = exp(p[12]*log(10.0))*log(10.0) ;
y[326+i**l] = exp(p[13]*log(10.0))*log(10.0) ;
y[351+i**l] = exp(p[14]*log(10.0))*log(10.0) ;
y[376+i**l] = exp(p[15]*log(10.0))*log(10.0) ;
y[401+i**l] = exp(p[16]*log(10.0))*log(10.0) ;
y[426+i**l] = exp(p[17]*log(10.0))*log(10.0) ;
y[451+i**l] = 1.0 ;
y[476+i**l] = exp(p[19]*log(10.0))*log(10.0) ;
y[501+i**l] = 1.0 ;
y[526+i**l] = exp(p[21]*log(10.0))*log(10.0) ;
y[551+i**l] = 1.0 ; 
}
}