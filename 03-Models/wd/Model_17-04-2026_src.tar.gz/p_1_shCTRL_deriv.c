#include <R.h>
 #include <math.h>
 void p_1_shCTRL_deriv_e1j28wty ( double * x, double * y, double * p, int * n, int * k, int * l ) {
 for(int i = 0; i< *n; i++) {
 y[0+i**l] = exp(p[0]*log(10.0))*log(10.0) ;
y[25+i**l] = exp(p[1]*log(10.0))*log(10.0) ;
y[50+i**l] = exp(p[2]*log(10.0))*log(10.0) ;
y[75+i**l] = exp(p[3]*log(10.0))*log(10.0) ;
y[100+i**l] = exp(p[4]*log(10.0))*log(10.0) ;
y[125+i**l] = exp(p[5]*log(10.0))*log(10.0) ;
y[151+i**l] = exp(p[6]*log(10.0))*log(10.0) ;
y[176+i**l] = exp(p[7]*log(10.0))*log(10.0) ;
y[202+i**l] = exp(p[8]*log(10.0))*log(10.0) ;
y[227+i**l] = exp(p[9]*log(10.0))*log(10.0) ;
y[252+i**l] = exp(p[10]*log(10.0))*log(10.0) ;
y[277+i**l] = exp(p[11]*log(10.0))*log(10.0) ;
y[302+i**l] = exp(p[12]*log(10.0))*log(10.0) ;
y[327+i**l] = exp(p[13]*log(10.0))*log(10.0) ;
y[352+i**l] = exp(p[14]*log(10.0))*log(10.0) ;
y[377+i**l] = exp(p[15]*log(10.0))*log(10.0) ;
y[402+i**l] = exp(p[16]*log(10.0))*log(10.0) ;
y[427+i**l] = exp(p[17]*log(10.0))*log(10.0) ;
y[452+i**l] = 1.0 ;
y[477+i**l] = exp(p[19]*log(10.0))*log(10.0) ;
y[502+i**l] = 1.0 ;
y[527+i**l] = exp(p[21]*log(10.0))*log(10.0) ; 
}
}