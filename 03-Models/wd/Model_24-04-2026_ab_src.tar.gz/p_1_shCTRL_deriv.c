#include <R.h>
 #include <math.h>
 void p_1_shCTRL_deriv_o56dnsct ( double * x, double * y, double * p, int * n, int * k, int * l ) {
 for(int i = 0; i< *n; i++) {
 y[0+i**l] = exp(p[0]*log(10.0))*log(10.0) ;
y[25+i**l] = exp(p[1]*log(10.0))*log(10.0) ;
y[50+i**l] = exp(p[2]*log(10.0))*log(10.0) ;
y[76+i**l] = exp(p[3]*log(10.0))*log(10.0) ;
y[101+i**l] = exp(p[4]*log(10.0))*log(10.0) ;
y[127+i**l] = exp(p[5]*log(10.0))*log(10.0) ;
y[154+i**l] = exp(p[6]*log(10.0))*log(10.0) ;
y[179+i**l] = exp(p[7]*log(10.0))*log(10.0) ;
y[205+i**l] = exp(p[8]*log(10.0))*log(10.0) ;
y[230+i**l] = exp(p[9]*log(10.0))*log(10.0) ;
y[255+i**l] = exp(p[10]*log(10.0))*log(10.0) ;
y[280+i**l] = exp(p[11]*log(10.0))*log(10.0) ;
y[305+i**l] = exp(p[12]*log(10.0))*log(10.0) ;
y[330+i**l] = exp(p[13]*log(10.0))*log(10.0) ;
y[355+i**l] = exp(p[14]*log(10.0))*log(10.0) ;
y[380+i**l] = 1.0 ;
y[405+i**l] = exp(p[16]*log(10.0))*log(10.0) ;
y[430+i**l] = 1.0 ;
y[455+i**l] = exp(p[18]*log(10.0))*log(10.0) ; 
}
}