#include <R.h>
 #include <math.h>
 void p_1_shCTRL_deriv_muga4tnt ( double * x, double * y, double * p, int * n, int * k, int * l ) {
 for(int i = 0; i< *n; i++) {
 y[0+i**l] = exp(p[0]*log(10.0))*log(10.0) ;
y[25+i**l] = exp(p[1]*log(10.0))*log(10.0) ;
y[50+i**l] = exp(p[2]*log(10.0))*log(10.0) ;
y[76+i**l] = exp(p[3]*log(10.0))*log(10.0) ;
y[101+i**l] = exp(p[4]*log(10.0))*log(10.0) ;
y[127+i**l] = exp(p[5]*log(10.0))*log(10.0) ;
y[154+i**l] = exp(p[6]*log(10.0))*log(10.0) ;
y[179+i**l] = exp(p[7]*log(10.0))*log(10.0) ;
y[204+i**l] = exp(p[8]*log(10.0))*log(10.0) ;
y[229+i**l] = exp(p[9]*log(10.0))*log(10.0) ;
y[254+i**l] = exp(p[10]*log(10.0))*log(10.0) ;
y[279+i**l] = exp(p[11]*log(10.0))*log(10.0) ;
y[304+i**l] = exp(p[12]*log(10.0))*log(10.0) ;
y[329+i**l] = exp(p[13]*log(10.0))*log(10.0) ;
y[354+i**l] = exp(p[14]*log(10.0))*log(10.0) ;
y[379+i**l] = exp(p[15]*log(10.0))*log(10.0) ;
y[404+i**l] = 1.0 ;
y[429+i**l] = exp(p[17]*log(10.0))*log(10.0) ;
y[454+i**l] = 1.0 ;
y[479+i**l] = exp(p[19]*log(10.0))*log(10.0) ; 
}
}