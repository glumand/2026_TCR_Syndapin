#include <R.h>
 #include <math.h>
 void p_1_shCTRL_deriv_mj9w8caq ( double * x, double * y, double * p, int * n, int * k, int * l ) {
 for(int i = 0; i< *n; i++) {
 y[0+i**l] = exp(p[0]*log(10.0))*log(10.0) ;
y[30+i**l] = exp(p[1]*log(10.0))*log(10.0) ;
y[57+i**l] = exp(p[2]*log(10.0))*log(10.0) ;
y[85+i**l] = exp(p[3]*log(10.0))*log(10.0) ;
y[112+i**l] = exp(p[4]*log(10.0))*log(10.0) ;
y[140+i**l] = exp(p[5]*log(10.0))*log(10.0) ;
y[167+i**l] = exp(p[6]*log(10.0))*log(10.0) ;
y[195+i**l] = exp(p[7]*log(10.0))*log(10.0) ;
y[222+i**l] = exp(p[8]*log(10.0))*log(10.0) ;
y[249+i**l] = exp(p[9]*log(10.0))*log(10.0) ;
y[276+i**l] = exp(p[10]*log(10.0))*log(10.0) ;
y[303+i**l] = exp(p[11]*log(10.0))*log(10.0) ;
y[330+i**l] = exp(p[12]*log(10.0))*log(10.0) ;
y[357+i**l] = exp(p[13]*log(10.0))*log(10.0) ;
y[384+i**l] = 1.0 ;
y[411+i**l] = exp(p[15]*log(10.0))*log(10.0) ;
y[438+i**l] = 1.0 ;
y[465+i**l] = exp(p[17]*log(10.0))*log(10.0) ; 
}
}