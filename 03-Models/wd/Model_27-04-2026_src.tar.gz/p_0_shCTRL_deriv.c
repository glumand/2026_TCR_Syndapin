#include <R.h>
 #include <math.h>
 void p_0_shCTRL_deriv_qkbt2o9w ( double * x, double * y, double * p, int * n, int * k, int * l ) {
 for(int i = 0; i< *n; i++) {
 y[11+i**l] = exp(p[0]*log(10.0))*log(10.0) ;
y[39+i**l] = exp(p[1]*log(10.0))*log(10.0) ;
y[67+i**l] = exp(p[2]*log(10.0))*log(10.0) ;
y[94+i**l] = exp(p[3]*log(10.0))*log(10.0) ;
y[121+i**l] = exp(p[4]*log(10.0))*log(10.0) ;
y[148+i**l] = exp(p[5]*log(10.0))*log(10.0) ;
y[175+i**l] = exp(p[6]*log(10.0))*log(10.0) ;
y[202+i**l] = 1.0 ;
y[229+i**l] = exp(p[8]*log(10.0))*log(10.0) ; 
}
}