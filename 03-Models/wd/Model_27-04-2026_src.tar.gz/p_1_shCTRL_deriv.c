#include <R.h>
 #include <math.h>
 void p_1_shCTRL_deriv_wr6saase ( double * x, double * y, double * p, int * n, int * k, int * l ) {
 for(int i = 0; i< *n; i++) {
 y[0+i**l] = exp(p[0]*log(10.0))*log(10.0) ;
y[31+i**l] = exp(p[1]*log(10.0))*log(10.0) ;
y[63+i**l] = exp(p[2]*log(10.0))*log(10.0) ;
y[91+i**l] = exp(p[3]*log(10.0))*log(10.0) ;
y[119+i**l] = exp(p[4]*log(10.0))*log(10.0) ;
y[146+i**l] = exp(p[5]*log(10.0))*log(10.0) ;
y[173+i**l] = exp(p[6]*log(10.0))*log(10.0) ;
y[200+i**l] = exp(p[7]*log(10.0))*log(10.0) ;
y[227+i**l] = exp(p[8]*log(10.0))*log(10.0) ;
y[254+i**l] = 1.0 ;
y[281+i**l] = exp(p[10]*log(10.0))*log(10.0) ; 
}
}