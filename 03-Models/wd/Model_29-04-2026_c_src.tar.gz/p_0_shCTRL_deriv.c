#include <R.h>
 #include <math.h>
 void p_0_shCTRL_deriv_iscusq3h ( double * x, double * y, double * p, int * n, int * k, int * l ) {
 for(int i = 0; i< *n; i++) {
 y[0+i**l] = exp(p[0]*log(10.0))*log(10.0) ;
y[24+i**l] = exp(p[1]*log(10.0))*log(10.0) ;
y[45+i**l] = exp(p[2]*log(10.0))*log(10.0) ;
y[67+i**l] = exp(p[3]*log(10.0))*log(10.0) ;
y[88+i**l] = exp(p[4]*log(10.0))*log(10.0) ;
y[109+i**l] = exp(p[5]*log(10.0))*log(10.0) ;
y[130+i**l] = exp(p[6]*log(10.0))*log(10.0) ;
y[151+i**l] = exp(p[7]*log(10.0))*log(10.0) ;
y[172+i**l] = exp(p[8]*log(10.0))*log(10.0) ;
y[193+i**l] = exp(p[9]*log(10.0))*log(10.0) ;
y[214+i**l] = exp(p[10]*log(10.0))*log(10.0) ;
y[235+i**l] = exp(p[11]*log(10.0))*log(10.0) ;
y[257+i**l] = exp(p[12]*log(10.0))*log(10.0) ;
y[278+i**l] = 1.0 ; 
}
}