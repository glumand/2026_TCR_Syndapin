#include <R.h>
 #include <math.h>
 void p_1_shCTRL_deriv_uf0c7ers ( double * x, double * y, double * p, int * n, int * k, int * l ) {
 for(int i = 0; i< *n; i++) {
 y[1+i**l] = exp(p[0]*log(10.0))*log(10.0) ;
y[22+i**l] = exp(p[1]*log(10.0))*log(10.0) ;
y[45+i**l] = exp(p[2]*log(10.0))*log(10.0) ;
y[67+i**l] = exp(p[3]*log(10.0))*log(10.0) ;
y[89+i**l] = exp(p[4]*log(10.0))*log(10.0) ;
y[110+i**l] = exp(p[5]*log(10.0))*log(10.0) ;
y[131+i**l] = exp(p[6]*log(10.0))*log(10.0) ;
y[152+i**l] = exp(p[7]*log(10.0))*log(10.0) ;
y[173+i**l] = exp(p[8]*log(10.0))*log(10.0) ;
y[194+i**l] = exp(p[9]*log(10.0))*log(10.0) ;
y[215+i**l] = exp(p[10]*log(10.0))*log(10.0) ;
y[237+i**l] = exp(p[11]*log(10.0))*log(10.0) ;
y[258+i**l] = 1.0 ; 
}
}