#include <R.h>
 #include <math.h>
 void g_zpyepoye ( double * x, double * y, double * p, int * n, int * k, int * l ) {
 for(int i = 0; i< *n; i++) {
 y[0+i**l] = log2(x[2+i**k]+x[3+i**k]+x[0+i**k]+x[1+i**k]+p[0])+p[1] ;
y[1+i**l] = log2(x[1+i**k]+p[2])+p[3] ;
y[2+i**l] = log2(x[1+i**k]+x[0+i**k]+p[4])+p[3] ;
y[3+i**l] = 1.0*(p[5]/(1.0+p[6]*(x[0+i**k]+x[1+i**k]*p[7])))-1.0*(p[8]*x[0+i**k])-1.0*(p[9]*x[0+i**k])+1.0*(p[10]*(x[0+i**k]+x[1+i**k]*p[7])*x[2+i**k]) ;
y[4+i**l] = -1.0*(p[11]*x[1+i**k]*p[7])-1.0*(p[12]*x[1+i**k]*p[7])+1.0*(p[13]*(x[1+i**k]+x[0+i**k])*x[3+i**k]*p[7]) ;
y[5+i**l] = 1.0*(p[9]*x[0+i**k])-1.0*(p[10]*(x[0+i**k]+x[1+i**k]*p[7])*x[2+i**k])-1.0*(p[14]*x[2+i**k]) ;
y[6+i**l] = 1.0*(p[12]*x[1+i**k]*p[7])-1.0*(p[13]*(x[1+i**k]+x[0+i**k])*x[3+i**k]*p[7])-1.0*(p[15]*x[3+i**k]*p[7]) ; 
}
}