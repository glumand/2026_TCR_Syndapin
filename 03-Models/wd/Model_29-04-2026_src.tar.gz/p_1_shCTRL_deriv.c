#include <R.h>
 #include <math.h>
 void p_1_shCTRL_deriv_bkappzto ( double * x, double * y, double * p, int * n, int * k, int * l ) {
 for(int i = 0; i< *n; i++) {
 y[1+i**l] = exp(p[0]*log(10.0))*log(10.0) ;
y[22+i**l] = exp(p[1]*log(10.0))*log(10.0) ;
y[44+i**l] = exp(p[2]*log(10.0))*log(10.0) ;
y[65+i**l] = exp(p[3]*log(10.0))*log(10.0) ;
y[87+i**l] = exp(p[4]*log(10.0))*log(10.0) ;
y[108+i**l] = exp(p[5]*log(10.0))*log(10.0) ;
y[129+i**l] = exp(p[6]*log(10.0))*log(10.0) ;
y[150+i**l] = exp(p[7]*log(10.0))*log(10.0) ;
y[171+i**l] = exp(p[8]*log(10.0))*log(10.0) ;
y[192+i**l] = exp(p[9]*log(10.0))*log(10.0) ;
y[213+i**l] = exp(p[10]*log(10.0))*log(10.0) ;
y[234+i**l] = exp(p[11]*log(10.0))*log(10.0) ;
y[255+i**l] = exp(p[12]*log(10.0))*log(10.0) ;
y[276+i**l] = 1.0 ;
y[297+i**l] = exp(p[14]*log(10.0))*log(10.0) ;
y[318+i**l] = 1.0 ; 
}
}